import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import {
  Activity, AlertTriangle, ArrowLeft, ArrowRight, Camera, Check, Disc3, Footprints,
  Gauge, Hand, Info, Keyboard, MoveHorizontal, Pause, Play, Power, RotateCcw,
  SlidersHorizontal, Smartphone, Timer, Trash2, Trophy, Volume2, VolumeX, Zap,
} from 'lucide-react';
import { ManualSim, GEAR_NAMES, type Gear, type SteerMode, type TimingAttempt } from './sim/simulation';
import { SimRenderer } from './sim/renderer';

type Tone = 'info' | 'success' | 'warning' | 'error';
interface Telemetry {
  speed: number; rpm: number; gear: Gear; engineRunning: boolean; cranking: boolean;
  clutch: number; gas: number; brake: number; handbrake: boolean; limiter: boolean;
  camera: 'cockpit' | 'chase'; paused: boolean; timingRunning: boolean; timingCurrent: number;
  best: number | null; attempts: TimingAttempt[]; distance: number; skid: number;
}
const INITIAL: Telemetry = {
  speed: 0, rpm: 0, gear: 'N', engineRunning: false, cranking: false, clutch: 1,
  gas: 0, brake: 0, handbrake: true, limiter: false, camera: 'cockpit', paused: false,
  timingRunning: false, timingCurrent: 0, best: null, attempts: [], distance: 0, skid: 0,
};
function snapshot(sim: ManualSim): Telemetry {
  return {
    speed: sim.speed, rpm: sim.rpm, gear: sim.gear, engineRunning: sim.engineRunning, cranking: sim.cranking,
    clutch: sim.clutch, gas: sim.gas, brake: sim.brake, handbrake: sim.handbrake, limiter: sim.limiterActive,
    camera: sim.camera, paused: sim.paused, timingRunning: sim.timing.running, timingCurrent: sim.timing.current,
    best: sim.timing.best, attempts: sim.timing.attempts, distance: sim.distance, skid: sim.skidIntensity,
  };
}
const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));

function Panel({ title, aside, children, className = '' }: { title: string; aside?: ReactNode; children: ReactNode; className?: string }) {
  return <section className={`panel ${className}`}>
    <div className="panel-head"><h2>{title}</h2>{aside}</div>
    {children}
  </section>;
}
function Key({ children }: { children: ReactNode }) { return <kbd className="key">{children}</kbd>; }

function HoldPedal({ label, hint, icon, value, onChange, variant }: {
  label: string; hint: string; icon: ReactNode; value: number; onChange: (v: number) => void; variant: 'clutch' | 'brake' | 'gas';
}) {
  const pointer = useRef<number | null>(null);
  const release = () => { pointer.current = null; onChange(0); };
  const pressed = value > 0.05;
  return <button
    type="button"
    className={`pedal pedal-${variant} ${pressed ? 'pressed' : ''}`}
    onContextMenu={e => e.preventDefault()}
    onPointerDown={e => { e.preventDefault(); pointer.current = e.pointerId; e.currentTarget.setPointerCapture(e.pointerId); onChange(1); }}
    onPointerUp={release}
    onPointerCancel={release}
    onLostPointerCapture={release}
    aria-pressed={pressed}
  >
    <span className="pedal-icon">{icon}</span>
    <span className="pedal-name">{label}</span>
    <span className="pedal-hint">{hint}</span>
    <span className="pedal-value">{Math.round(value * 100)}%</span>
    <span className="pedal-fill" style={{ height: `${Math.round(value * 100)}%` }} />
  </button>;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const simRef = useRef<ManualSim | null>(null);
  const rendererRef = useRef<SimRenderer | null>(null);
  const keysRef = useRef<Set<string>>(new Set());
  const [tele, setTele] = useState<Telemetry>(INITIAL);
  const [status, setStatus] = useState<{ message: string; tone: Tone }>({ message: 'Ignition is OFF. Hold clutch, select Neutral, then START ENGINE.', tone: 'info' });
  const [audioOn, setAudioOn] = useState(false);
  const [steerMode, setSteerMode] = useState<SteerMode>('buttons');
  const [slider, setSlider] = useState(0);
  const [gyro, setGyro] = useState<'idle' | 'active' | 'denied' | 'unsupported'>('idle');
  const [stalled, setStalled] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const sim = new ManualSim();
    const renderer = new SimRenderer(canvas);
    simRef.current = sim;
    rendererRef.current = renderer;
    setTele(snapshot(sim));
    const observer = new ResizeObserver(() => renderer.resize());
    observer.observe(canvas);
    let raf = 0;
    let last = performance.now();
    let accum = 0;
    const tick = (now: number) => {
      const dt = Math.min((now - last) / 1000, 0.05);
      last = now;
      sim.update(dt);
      renderer.draw(sim, sim.paused ? 0 : dt);
      const events = sim.consumeEvents();
      if (events.length) {
        const event = events[events.length - 1];
        setStatus({ message: event.message, tone: event.tone });
        if (event.type === 'stall') setStalled(true);
        if (event.type === 'start') setStalled(false);
      }
      accum += dt;
      if (accum > 0.075) { accum = 0; setTele(snapshot(sim)); }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => { cancelAnimationFrame(raf); observer.disconnect(); sim.audio.destroy(); simRef.current = null; rendererRef.current = null; };
  }, []);

  const toggleAudio = useCallback(() => {
    const sim = simRef.current;
    if (!sim) return;
    setAudioOn(prev => {
      const next = !prev;
      sim.audio.init();
      sim.audio.setMuted(!next);
      if (next) sim.audio.resume();
      sim.notify(next ? 'Audio enabled. Engine, tires, and gearbox are live.' : 'Audio muted.', 'info');
      return next;
    });
  }, []);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const sim = simRef.current;
      if (!sim) return;
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) return;
      const k = e.key.toLowerCase();
      keysRef.current.add(k);
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
      if (k === 'shift') sim.setClutch(1);
      if (k === 'w' || k === 'arrowup') sim.setGas(1);
      if (k === 's' || k === 'arrowdown') sim.setBrake(1);
      if (k === 'a' || k === 'arrowleft') sim.setSteer(-1);
      if (k === 'd' || k === 'arrowright') sim.setSteer(1);
      if (e.repeat) return;
      if (k === ' ') sim.toggleHandbrake();
      if (['1', '2', '3', '4', '5', '6'].includes(k)) sim.selectGear(k as Gear);
      if (k === 'n') sim.selectGear('N');
      if (k === 'r') sim.selectGear('R');
      if (k === 'e') sim.startEngine();
      if (k === 'c') sim.toggleCamera();
      if (k === 'm') toggleAudio();
      if (k === 'p') sim.togglePause();
      if (k === 'escape' && sim.paused) sim.togglePause();
    };
    const up = (e: KeyboardEvent) => {
      const sim = simRef.current;
      if (!sim) return;
      const k = e.key.toLowerCase();
      keysRef.current.delete(k);
      if (k === 'shift') sim.setClutch(0);
      const keys = keysRef.current;
      if ((k === 'w' || k === 'arrowup') && !keys.has('w') && !keys.has('arrowup')) sim.setGas(0);
      if ((k === 's' || k === 'arrowdown') && !keys.has('s') && !keys.has('arrowdown')) sim.setBrake(0);
      if (!keys.has('a') && !keys.has('arrowleft') && !keys.has('d') && !keys.has('arrowright')) sim.setSteer(0);
    };
    const blur = () => { keysRef.current.clear(); const sim = simRef.current; if (sim) { sim.setGas(0); sim.setBrake(0); sim.setClutch(0); sim.setSteer(0); } };
    window.addEventListener('keydown', down);
    window.addEventListener('keyup', up);
    window.addEventListener('blur', blur);
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up); window.removeEventListener('blur', blur); };
  }, [toggleAudio]);

  useEffect(() => {
    const sim = simRef.current;
    if (!sim) return;
    sim.steerMode = steerMode;
    if (steerMode !== 'tilt') return;
    const handler = (e: DeviceOrientationEvent) => {
      if (e.gamma !== null) {
        sim.setSteer(clamp(e.gamma / 28, -1, 1));
        setGyro('active');
      }
    };
    window.addEventListener('deviceorientation', handler);
    return () => window.removeEventListener('deviceorientation', handler);
  }, [steerMode]);

  const chooseSteerMode = async (mode: SteerMode) => {
    const sim = simRef.current;
    setSteerMode(mode);
    if (!sim) return;
    sim.setSteer(0);
    if (mode === 'tilt') {
      const DOE = (window as unknown as { DeviceOrientationEvent?: { requestPermission?: () => Promise<string> } }).DeviceOrientationEvent;
      if (!DOE) {
        setGyro('unsupported');
        sim.notify('Gyro steering is not available on this device.', 'warning');
        return;
      }
      if (typeof DOE.requestPermission === 'function') {
        try {
          const result = await DOE.requestPermission();
          if (result !== 'granted') {
            setGyro('denied');
            sim.notify('Gyro permission denied. Use buttons or slider.', 'warning');
            return;
          }
        } catch {
          setGyro('denied');
          sim.notify('Gyro permission failed. Use buttons or slider.', 'warning');
          return;
        }
      }
      setGyro('active');
      sim.notify('Gyro steering armed. Tilt your device left and right.', 'info');
    }
  };

  const setPedal = (kind: 'clutch' | 'gas' | 'brake', value: number) => {
    const sim = simRef.current;
    if (!sim) return;
    sim.audio.init();
    sim.audio.resume();
    if (kind === 'clutch') sim.setClutch(value);
    if (kind === 'gas') sim.setGas(value);
    if (kind === 'brake') sim.setBrake(value);
  };

  const shiftAlert = tele.engineRunning && tele.rpm > 6500 && tele.gear !== '6' && tele.gear !== 'N' && tele.gear !== 'R' && !tele.paused;
  const clutchPct = Math.round((1 - tele.clutch) * 100);
  const clutchLabel = clutchPct >= 98 ? 'LOCKED' : clutchPct <= 2 ? 'DISENGAGED' : 'SLIPPING';
  const engineLabel = tele.cranking ? 'CRANK' : tele.engineRunning ? 'RUN' : stalled ? 'STALL' : 'OFF';
  const timerText = tele.timingRunning
    ? `0–100: ${tele.timingCurrent.toFixed(1)} s`
    : tele.best !== null ? `0–100 BEST: ${tele.best.toFixed(2)} s` : '0–100: --.- s';
  const StatusIcon = status.tone === 'success' ? Check : status.tone === 'info' ? Info : AlertTriangle;
  const gears: { gear: Gear; className: string }[] = [
    { gear: '1', className: 'slot-1' }, { gear: '3', className: 'slot-3' }, { gear: '5', className: 'slot-5' },
    { gear: 'R', className: 'slot-r' }, { gear: 'N', className: 'slot-n' },
    { gear: '2', className: 'slot-2' }, { gear: '4', className: 'slot-4' }, { gear: '6', className: 'slot-6' },
  ];

  return <div className="app min-h-screen">
    <header className="topbar">
      <div className="brand">
        <span className="brand-badge"><Gauge size={20} /></span>
        <div>
          <h1>MANUAL RACING SIMULATOR</h1>
          <p>FWD · 6-SPEED MANUAL · CLUTCH REQUIRED</p>
        </div>
        <span className="pro-tag">PRO</span>
      </div>
      <div className="top-actions">
        <button className={`tool-btn ${audioOn ? 'active' : ''}`} onClick={toggleAudio} aria-pressed={audioOn}>
          {audioOn ? <Volume2 size={16} /> : <VolumeX size={16} />}<span>Audio {audioOn ? 'ON' : 'OFF'}</span>
        </button>
        <button className="tool-btn" onClick={() => simRef.current?.toggleCamera()}>
          <Camera size={16} /><span>{tele.camera === 'cockpit' ? 'Cockpit' : 'Chase'}</span>
        </button>
        <button className={`tool-btn ${tele.paused ? 'active' : ''}`} onClick={() => simRef.current?.togglePause()}>
          {tele.paused ? <Play size={16} /> : <Pause size={16} />}<span>{tele.paused ? 'Resume' : 'Pause'}</span>
        </button>
      </div>
    </header>

    <main className="main">
      <section className="viewport-shell">
        <div className="viewport">
          <canvas ref={canvasRef} className="scene" aria-label="Driving simulation viewport" />
          <div className="hud-badges">
            <span className="badge"><Activity size={12} />FWD · MANUAL 6-SPD</span>
            <span className={`badge ${tele.timingRunning ? 'badge-live' : ''}`}><Timer size={12} />{timerText}</span>
            <span className="badge"><Camera size={12} />{tele.camera === 'cockpit' ? 'COCKPIT' : 'CHASE'}</span>
          </div>
          {shiftAlert && <div className="shift-alert">SHIFT UP</div>}
          {tele.limiter && tele.engineRunning && <div className="limiter-flash" />}

          {!tele.engineRunning && !tele.cranking && !tele.paused && <div className="ignition-overlay">
            <div className={`ignition-card ${stalled ? 'stalled' : ''}`}>
              <p className="eyebrow">{stalled ? 'ENGINE STALLED' : 'IGNITION OFF'}</p>
              <h2>{stalled ? 'RESTART THE ENGINE' : 'READY TO DRIVE?'}</h2>
              <p>{stalled
                ? 'Hold the clutch, press START, then add throttle as you release the clutch.'
                : 'Hold clutch, select Neutral or 1st, start the engine, then release the handbrake.'}</p>
              <button className="primary-btn" onClick={() => simRef.current?.startEngine()}><Power size={17} />START ENGINE</button>
            </div>
          </div>}

          {tele.paused && <div className="pause-overlay">
            <div className="pause-card">
              <Pause size={26} />
              <h2>SIMULATION PAUSED</h2>
              <p>Physics, timing, and audio are frozen.</p>
              <div className="pause-actions">
                <button className="primary-btn" onClick={() => simRef.current?.togglePause()}><Play size={16} />RESUME</button>
                <button className="ghost-btn" onClick={() => { const sim = simRef.current; if (!sim) return; sim.resetCar(); if (sim.paused) sim.togglePause(); }}><RotateCcw size={15} />RESET CAR</button>
              </div>
            </div>
          </div>}
        </div>

        <div className="dash">
          <div className="metric">
            <span className="metric-label">SPEED</span>
            <strong className="metric-value">{Math.round(Math.abs(tele.speed))}</strong>
            <span className="metric-sub">KM/H</span>
          </div>
          <div className="metric">
            <span className="metric-label">GEAR</span>
            <strong className={`metric-value gear-value ${tele.gear === 'R' ? 'reverse' : ''}`}>{tele.gear}</strong>
            <span className="metric-sub">{GEAR_NAMES[tele.gear]}</span>
          </div>
          <div className="metric">
            <span className="metric-label">TACHOMETER</span>
            <strong className={`metric-value ${tele.rpm > 6600 ? 'redline' : ''}`}>{Math.round(tele.rpm)}</strong>
            <span className="metric-sub">RPM</span>
            <span className="rpm-track"><i style={{ width: `${clamp(tele.rpm / 8000, 0, 1) * 100}%` }} /></span>
          </div>
          <div className="metric">
            <span className="metric-label">ENGINE</span>
            <strong className={`metric-value engine-value ${tele.engineRunning ? 'on' : stalled ? 'stall' : 'off'}`}>{engineLabel}</strong>
            <span className="metric-sub">{tele.engineRunning ? '880 RPM idle' : tele.cranking ? 'Starter engaged' : 'Starter ready'}</span>
          </div>
          <div className="clutch-meter">
            <div className="clutch-row">
              <span>CLUTCH FRICTION ENGAGEMENT</span>
              <span>{clutchPct}% · {clutchLabel}</span>
            </div>
            <div className="bar-track"><i style={{ width: `${clutchPct}%` }} /></div>
          </div>
        </div>
      </section>

      <div className={`status status-${status.tone}`} role="status">
        <StatusIcon size={16} /><span>{status.message}</span>
      </div>

      <div className="control-deck">
        <Panel title="H-PATTERN 6-SPEED" aside={
          <button className={`engine-btn ${tele.engineRunning ? 'running' : ''}`} disabled={tele.cranking} onClick={() => simRef.current?.startEngine()}>
            <Power size={14} />{tele.cranking ? 'CRANKING…' : tele.engineRunning ? 'STOP ENGINE' : 'START ENGINE'}
          </button>
        }>
          <div className="shifter-wrap">
            <div className="h-gate" role="group" aria-label="Gear shifter">
              <svg className="gate-lines" viewBox="0 0 230 150" aria-hidden="true">
                <path d="M40 32 V118 M115 32 V118 M190 32 V118 M40 75 H190 M190 75 H212" />
              </svg>
              {gears.map(({ gear, className }) => <button
                key={gear}
                type="button"
                className={`h-slot ${className} ${tele.gear === gear ? 'selected' : ''} ${gear === 'R' ? 'reverse-slot' : ''}`}
                onClick={() => simRef.current?.selectGear(gear)}
                aria-pressed={tele.gear === gear}
                aria-label={`Select ${GEAR_NAMES[gear]}`}
              >{gear}</button>)}
            </div>
            <p className="tip"><strong>Pro tip:</strong> hold <Key>Shift</Key> or the clutch pedal before shifting. Release gently with throttle to avoid stalling.</p>
          </div>
          <div className="button-row">
            <button className={`secondary-btn ${tele.handbrake ? 'active' : ''}`} onClick={() => simRef.current?.toggleHandbrake()} aria-pressed={tele.handbrake}>
              <Hand size={15} />Handbrake {tele.handbrake ? 'ON' : 'OFF'}
            </button>
            <button className="secondary-btn" onClick={() => simRef.current?.resetCar()}><RotateCcw size={15} />Reset car</button>
          </div>
        </Panel>

        <Panel title="PEDAL BOX" aside={<span className="panel-note">MULTI-TOUCH</span>}>
          <div className="pedal-rack">
            <HoldPedal label="CLUTCH" hint="SHIFT" icon={<Footprints size={22} />} value={tele.clutch} onChange={v => setPedal('clutch', v)} variant="clutch" />
            <HoldPedal label="BRAKE" hint="S / ↓" icon={<Disc3 size={22} />} value={tele.brake} onChange={v => setPedal('brake', v)} variant="brake" />
            <HoldPedal label="THROTTLE" hint="W / ↑" icon={<Zap size={22} />} value={tele.gas} onChange={v => setPedal('gas', v)} variant="gas" />
          </div>
          <div className="pedal-note">
            <span><i className="dot dot-amber" />Clutch disengages the engine.</span>
            <span><i className="dot dot-green" />Throttle feeds the revs.</span>
            <span><i className="dot dot-red" />Brake slows the wheels.</span>
          </div>
        </Panel>

        <Panel title="STEERING & TIMING" aside={<span className="panel-note">{Math.round(tele.distance)} m</span>}>
          <div className="steer-modes" role="group" aria-label="Steering method">
            <button className={steerMode === 'buttons' ? 'active' : ''} onClick={() => void chooseSteerMode('buttons')}><MoveHorizontal size={14} />Buttons</button>
            <button className={steerMode === 'slider' ? 'active' : ''} onClick={() => void chooseSteerMode('slider')}><SlidersHorizontal size={14} />Slider</button>
            <button className={steerMode === 'tilt' ? 'active' : ''} onClick={() => void chooseSteerMode('tilt')}><Smartphone size={14} />Gyro</button>
          </div>
          {steerMode === 'buttons' && <div className="steer-buttons">
            <button className="steer-btn" onContextMenu={e => e.preventDefault()}
              onPointerDown={e => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); simRef.current?.setSteer(-1); }}
              onPointerUp={() => simRef.current?.setSteer(0)} onPointerCancel={() => simRef.current?.setSteer(0)} onLostPointerCapture={() => simRef.current?.setSteer(0)}
            ><ArrowLeft size={18} />LEFT</button>
            <button className="steer-btn" onContextMenu={e => e.preventDefault()}
              onPointerDown={e => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); simRef.current?.setSteer(1); }}
              onPointerUp={() => simRef.current?.setSteer(0)} onPointerCancel={() => simRef.current?.setSteer(0)} onLostPointerCapture={() => simRef.current?.setSteer(0)}
            >RIGHT<ArrowRight size={18} /></button>
          </div>}
          {steerMode === 'slider' && <div className="slider-box">
            <input type="range" min={-100} max={100} value={slider} aria-label="Steering wheel slider"
              onChange={e => { const v = Number(e.target.value); setSlider(v); simRef.current?.setSteer(v / 100); }} />
            <div className="slider-labels"><span>LEFT</span><span>CENTER</span><span>RIGHT</span></div>
          </div>}
          {steerMode === 'tilt' && <div className="gyro-box">
            <Smartphone size={18} />
            <span>{gyro === 'active' ? 'Tilt active · steer with your device' : gyro === 'denied' ? 'Permission denied · use buttons/slider' : gyro === 'unsupported' ? 'Gyro unavailable · use buttons/slider' : 'Waiting for gyro…'}</span>
          </div>}

          <div className="timing-board">
            <div className="timing-head"><span><Trophy size={14} />0–100 KM/H</span><strong>{tele.best !== null ? `${tele.best.toFixed(2)} s` : '--.-- s'}</strong></div>
            {tele.attempts.length ? <ol className="attempts">
              {tele.attempts.slice(0, 4).map((a, i) => <li key={`${a.date}-${i}`}><span>{i + 1}</span><span>{new Date(a.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span><strong>{a.time.toFixed(2)} s</strong></li>)}
            </ol> : <p className="empty-attempts">Launch from standstill to start the timer. Your best runs stay on this device.</p>}
            {tele.attempts.length > 0 && <button className="clear-btn" onClick={() => simRef.current?.clearTiming()}><Trash2 size={12} />Clear timing board</button>}
          </div>
        </Panel>
      </div>

      <footer className="keyboard-bar">
        <span className="keyboard-title"><Keyboard size={15} />KEYBOARD</span>
        <span><Key>W</Key>/<Key>↑</Key> throttle</span>
        <span><Key>S</Key>/<Key>↓</Key> brake</span>
        <span><Key>Shift</Key> clutch</span>
        <span><Key>1</Key>–<Key>6</Key> gears</span>
        <span><Key>N</Key> neutral</span>
        <span><Key>R</Key> reverse</span>
        <span><Key>Space</Key> handbrake</span>
        <span><Key>E</Key> ignition</span>
        <span><Key>C</Key> camera</span>
        <span><Key>P</Key> pause</span>
      </footer>
    </main>
  </div>;
}
