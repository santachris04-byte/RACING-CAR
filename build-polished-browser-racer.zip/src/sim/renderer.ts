import type { ManualSim } from './simulation';

const SEGMENT_LENGTH = 200;
const ROAD_LENGTH = 1200;
const TRACK_LENGTH = ROAD_LENGTH * SEGMENT_LENGTH;
const ROAD_WIDTH = 2100;
const CAMERA_HEIGHT = 1050;
const CAMERA_DEPTH = 0.84;
const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

interface Point {
  world: { x: number; y: number; z: number };
  camera: { x: number; y: number; z: number };
  screen: { x: number; y: number; w: number; scale: number };
}
interface Segment {
  index: number;
  curve: number;
  hill: number;
  p1: Point;
  p2: Point;
  alt: boolean;
}
interface Particle { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; kind: 'smoke' | 'spark' }

function makePoint(z: number): Point {
  return { world: { x: 0, y: 0, z }, camera: { x: 0, y: 0, z: 0 }, screen: { x: 0, y: 0, w: 0, scale: 0 } };
}

export class SimRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private width = 960;
  private height = 400;
  private dpr = 1;
  private segments: Segment[] = [];
  private particles: Particle[] = [];

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas 2D unavailable');
    this.ctx = ctx;
    for (let i = 0; i < ROAD_LENGTH; i++) {
      this.segments.push({
        index: i,
        curve: Math.sin(i / 38) * 1.7 + Math.cos(i / 85) * 2.1,
        hill: Math.sin(i / 30) * 780 + Math.cos(i / 70) * 380,
        p1: makePoint(i * SEGMENT_LENGTH),
        p2: makePoint((i + 1) * SEGMENT_LENGTH),
        alt: Math.floor(i / 3) % 2 === 0,
      });
    }
    this.resize();
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    this.width = Math.max(1, rect.width);
    this.height = Math.max(1, rect.height);
    this.dpr = Math.min(window.devicePixelRatio || 1, this.width < 600 ? 1.25 : 1.5);
    this.canvas.width = Math.round(this.width * this.dpr);
    this.canvas.height = Math.round(this.height * this.dpr);
  }

  private project(p: Point, cameraX: number, cameraY: number, cameraZ: number) {
    p.camera.x = p.world.x - cameraX;
    p.camera.y = p.world.y - cameraY;
    p.camera.z = p.world.z - cameraZ;
    p.screen.scale = CAMERA_DEPTH / Math.max(1, p.camera.z);
    p.screen.x = this.width / 2 + (p.screen.scale * p.camera.x * this.width) / 2;
    p.screen.y = this.height / 2 - (p.screen.scale * p.camera.y * this.height) / 2;
    p.screen.w = (p.screen.scale * ROAD_WIDTH * this.width) / 2;
  }

  private trapezoid(x1: number, y1: number, w1: number, x2: number, y2: number, w2: number, color: string) {
    const ctx = this.ctx;
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x1 - w1, y1);
    ctx.lineTo(x1 + w1, y1);
    ctx.lineTo(x2 + w2, y2);
    ctx.lineTo(x2 - w2, y2);
    ctx.closePath();
    ctx.fill();
  }

  draw(sim: ManualSim, dt: number) {
    const ctx = this.ctx;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    ctx.save();
    if (sim.shake > 0.2) ctx.translate((Math.random() - 0.5) * sim.shake, (Math.random() - 0.5) * sim.shake * 0.7);

    this.drawEnvironment(sim);
    this.drawRoad(sim);
    this.updateParticles(sim, dt);
    this.drawParticles();
    if (sim.camera === 'cockpit') this.drawCockpit(sim);
    else this.drawChaseCar(sim);
    if (Math.abs(sim.speed) > 120) this.drawSpeedLines(sim);
    ctx.restore();
  }

  private drawEnvironment(sim: ManualSim) {
    const ctx = this.ctx, w = this.width, h = this.height;
    const horizon = h * 0.46;
    const sky = ctx.createLinearGradient(0, 0, 0, horizon * 1.15);
    sky.addColorStop(0, '#101826');
    sky.addColorStop(0.55, '#253750');
    sky.addColorStop(1, '#8a6a4f');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);

    // Low sun and haze.
    const sunX = w * 0.68 - sim.carX * 14;
    const sunY = horizon * 0.78;
    const glow = ctx.createRadialGradient(sunX, sunY, 4, sunX, sunY, h * 0.24);
    glow.addColorStop(0, 'rgba(255,190,110,0.85)');
    glow.addColorStop(0.35, 'rgba(255,160,90,0.25)');
    glow.addColorStop(1, 'rgba(255,160,90,0)');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, w, horizon);
    ctx.fillStyle = '#ffd9a0';
    ctx.beginPath();
    ctx.arc(sunX, sunY, h * 0.045, 0, Math.PI * 2);
    ctx.fill();

    // Parallax mountain ridges.
    const offset = sim.trackPosition * 0.018 + sim.carX * 22;
    ctx.fillStyle = '#1b2739';
    ctx.beginPath();
    ctx.moveTo(0, horizon);
    for (let x = 0; x <= w; x += 28) {
      const y = horizon - 26 - Math.sin((x + offset) * 0.012) * 22 - Math.cos((x + offset) * 0.031) * 9;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(w, horizon);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#111b29';
    ctx.beginPath();
    ctx.moveTo(0, horizon);
    for (let x = 0; x <= w; x += 24) {
      const y = horizon - 10 - Math.sin((x + offset * 1.6) * 0.02) * 13;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(w, horizon);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#0d2018';
    ctx.fillRect(0, horizon, w, h - horizon);
  }

  private drawRoad(sim: ManualSim) {
    const ctx = this.ctx, w = this.width, h = this.height;
    const position = ((sim.trackPosition % TRACK_LENGTH) + TRACK_LENGTH) % TRACK_LENGTH;
    const base = Math.floor(position / SEGMENT_LENGTH);
    const basePercent = (position % SEGMENT_LENGTH) / SEGMENT_LENGTH;
    const baseSegment = this.segments[base % ROAD_LENGTH];
    const nextSegment = this.segments[(base + 1) % ROAD_LENGTH];
    const playerY = lerp(baseSegment.hill, nextSegment.hill, basePercent);
    const drawDistance = w < 600 ? 95 : 135;
    let x = 0;
    let dx = -(baseSegment.curve * basePercent);
    let maxy = h;

    for (let n = 0; n < drawDistance; n++) {
      const idx = (base + n) % ROAD_LENGTH;
      const seg = this.segments[idx];
      const looped = idx < base;
      const zOffset = looped ? TRACK_LENGTH : 0;
      seg.p1.world.y = seg.hill;
      seg.p2.world.y = this.segments[(idx + 1) % ROAD_LENGTH].hill;
      seg.p1.world.z = idx * SEGMENT_LENGTH + zOffset;
      seg.p2.world.z = (idx + 1) * SEGMENT_LENGTH + zOffset;

      this.project(seg.p1, sim.carX * ROAD_WIDTH - x, playerY + CAMERA_HEIGHT, position);
      this.project(seg.p2, sim.carX * ROAD_WIDTH - x - dx, playerY + CAMERA_HEIGHT, position);
      x += dx;
      dx += seg.curve;

      const p1 = seg.p1.screen, p2 = seg.p2.screen;
      if (seg.p1.camera.z <= CAMERA_DEPTH || p2.y >= maxy || p2.y >= p1.y) continue;

      const grass = seg.alt ? '#123024' : '#0f281e';
      const road = seg.alt ? '#2c3540' : '#28303b';
      const rumble = seg.alt ? '#d95040' : '#e9e4d8';
      ctx.fillStyle = grass;
      ctx.fillRect(0, p2.y, w, p1.y - p2.y + 1);
      this.trapezoid(p1.x, p1.y, p1.w * 1.16, p2.x, p2.y, p2.w * 1.16, rumble);
      this.trapezoid(p1.x, p1.y, p1.w, p2.x, p2.y, p2.w, road);
      // Edge lines.
      this.trapezoid(p1.x - p1.w * 0.94, p1.y, p1.w * 0.018, p2.x - p2.w * 0.94, p2.y, p2.w * 0.018, '#d8d4c8');
      this.trapezoid(p1.x + p1.w * 0.94, p1.y, p1.w * 0.018, p2.x + p2.w * 0.94, p2.y, p2.w * 0.018, '#d8d4c8');
      // Center dashed line.
      if (seg.alt) {
        this.trapezoid(p1.x, p1.y, p1.w * 0.022, p2.x, p2.y, p2.w * 0.022, '#f1ede0');
      }

      // Roadside reflectors and trees, clipped by the road horizon.
      if (seg.index % 4 === 0 && p1.w > 5) {
        const postH = p1.w * 0.11;
        for (const side of [-1, 1]) {
          const px = p1.x + side * p1.w * 1.24;
          if (px < -30 || px > w + 30) continue;
          ctx.fillStyle = '#39424e';
          ctx.fillRect(px - p1.w * 0.008, p1.y - postH, Math.max(1, p1.w * 0.016), postH);
          ctx.fillStyle = seg.alt ? '#ffb45e' : '#e8e4d8';
          ctx.fillRect(px - p1.w * 0.014, p1.y - postH, Math.max(1.5, p1.w * 0.028), Math.max(1.5, p1.w * 0.022));
        }
      }
      if (seg.index % 9 === 0 && p1.w > 9) {
        const side = seg.index % 18 === 0 ? -1 : 1;
        const tx = p1.x + side * p1.w * (1.7 + (seg.index % 5) * 0.16);
        const th = p1.w * 0.7;
        if (tx > -th && tx < w + th) {
          ctx.fillStyle = '#0a1c15';
          ctx.beginPath();
          ctx.moveTo(tx, p1.y - th);
          ctx.lineTo(tx - th * 0.34, p1.y);
          ctx.lineTo(tx + th * 0.34, p1.y);
          ctx.closePath();
          ctx.fill();
        }
      }
      maxy = p2.y;
    }

    // Atmospheric haze near the horizon.
    const haze = ctx.createLinearGradient(0, h * 0.4, 0, h * 0.62);
    haze.addColorStop(0, 'rgba(138,106,79,0.28)');
    haze.addColorStop(1, 'rgba(138,106,79,0)');
    ctx.fillStyle = haze;
    ctx.fillRect(0, h * 0.4, w, h * 0.22);
  }

  private drawCockpit(sim: ManualSim) {
    const ctx = this.ctx, w = this.width, h = this.height;
    // Dashboard cowl.
    ctx.fillStyle = '#0a0f17';
    ctx.beginPath();
    ctx.moveTo(0, h);
    ctx.lineTo(0, h * 0.74);
    ctx.quadraticCurveTo(w * 0.5, h * 0.58, w, h * 0.74);
    ctx.lineTo(w, h);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#202c3d';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,180,94,0.05)';
    ctx.fillRect(0, h * 0.74, w, h * 0.26);

    // Shift lights.
    const lights = 7;
    const lit = Math.floor(clamp((sim.rpm - 4200) / (sim.maxRpm - 4200), 0, 1) * lights);
    for (let i = 0; i < lights; i++) {
      const lx = w / 2 + (i - (lights - 1) / 2) * 18;
      ctx.fillStyle = i < lit ? (i > 4 ? '#ff4757' : i > 2 ? '#ffb84d' : '#59d98c') : '#1d2735';
      ctx.beginPath();
      ctx.arc(lx, h * 0.665, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }

    this.drawGauge(w * 0.29, h * 0.8, Math.min(w * 0.115, 58), sim.rpm, 8000, 'RPM', true, sim);
    this.drawGauge(w * 0.71, h * 0.8, Math.min(w * 0.115, 58), Math.abs(sim.speed), 280, 'KM/H', false, sim);

    // Digital gear readout.
    ctx.fillStyle = '#0d1420';
    ctx.fillRect(w / 2 - 26, h * 0.755, 52, 40);
    ctx.strokeStyle = '#2b394e';
    ctx.strokeRect(w / 2 - 26, h * 0.755, 52, 40);
    ctx.fillStyle = sim.gear === 'R' ? '#ff6b6b' : sim.gear === 'N' ? '#9fb0c6' : '#ffbf69';
    ctx.font = '700 28px "Chakra Petch", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(sim.gear, w / 2, h * 0.755 + 21);

    // Steering wheel.
    const wheelX = w * 0.5, wheelY = h * 1.05;
    const radius = Math.min(w * 0.21, 122);
    ctx.save();
    ctx.translate(wheelX, wheelY);
    ctx.rotate(sim.steer * 1.55);
    ctx.lineWidth = 21;
    ctx.strokeStyle = '#1c2635';
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.lineWidth = 13;
    ctx.strokeStyle = '#0d141e';
    ctx.stroke();
    ctx.strokeStyle = '#ff5d4d';
    ctx.lineWidth = 13;
    ctx.beginPath();
    ctx.arc(0, 0, radius, -Math.PI / 2 - 0.08, -Math.PI / 2 + 0.08);
    ctx.stroke();
    ctx.strokeStyle = '#33415a';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(-radius + 12, 0); ctx.lineTo(radius - 12, 0);
    ctx.moveTo(0, 0); ctx.lineTo(0, radius - 12);
    ctx.stroke();
    ctx.fillStyle = '#060a11';
    ctx.beginPath();
    ctx.arc(0, 0, 25, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ffbf69';
    ctx.font = '700 11px "Chakra Petch", sans-serif';
    ctx.fillText('GT-M', 0, 1);
    ctx.restore();
  }

  private drawGauge(x: number, y: number, radius: number, value: number, max: number, label: string, isRpm: boolean, sim: ManualSim) {
    const ctx = this.ctx;
    ctx.save();
    ctx.translate(x, y);
    ctx.fillStyle = 'rgba(8,12,20,0.94)';
    ctx.beginPath();
    ctx.arc(0, 0, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#33415a';
    ctx.lineWidth = 3;
    ctx.stroke();
    const start = Math.PI * 0.75, sweep = Math.PI * 1.5;
    if (isRpm) {
      ctx.strokeStyle = 'rgba(255,71,87,0.75)';
      ctx.lineWidth = 5;
      ctx.beginPath();
      ctx.arc(0, 0, radius - 6, start + sweep * (sim.redlineRpm / max), start + sweep);
      ctx.stroke();
    }
    ctx.strokeStyle = '#4b5b73';
    ctx.lineWidth = 1.5;
    for (let i = 0; i <= 8; i++) {
      const a = start + sweep * (i / 8);
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * (radius - 5), Math.sin(a) * (radius - 5));
      ctx.lineTo(Math.cos(a) * (radius - 11), Math.sin(a) * (radius - 11));
      ctx.stroke();
    }
    const angle = start + clamp(value / max, 0, 1) * sweep;
    ctx.strokeStyle = isRpm && value > sim.redlineRpm ? '#ff4757' : '#67d1ff';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(Math.cos(angle) * (radius - 10), Math.sin(angle) * (radius - 10));
    ctx.stroke();
    ctx.fillStyle = '#f4f7fb';
    ctx.beginPath();
    ctx.arc(0, 0, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#93a4bc';
    ctx.font = '600 9px "IBM Plex Mono", monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillText(label, 0, radius * 0.52);
    ctx.restore();
  }

  private drawChaseCar(sim: ManualSim) {
    const ctx = this.ctx, w = this.width, h = this.height;
    const cx = w / 2 + sim.steer * 10;
    const cy = h * 0.8;
    const cw = Math.min(w * 0.25, 155);
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(sim.steer * 0.035);
    ctx.fillStyle = 'rgba(0,0,0,0.45)';
    ctx.beginPath();
    ctx.ellipse(0, cw * 0.2, cw * 0.58, cw * 0.14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#05080e';
    ctx.fillRect(-cw * 0.49, -cw * 0.14, cw * 0.17, cw * 0.42);
    ctx.fillRect(cw * 0.32, -cw * 0.14, cw * 0.17, cw * 0.42);
    const body = ctx.createLinearGradient(0, -cw * 0.65, 0, cw * 0.18);
    body.addColorStop(0, '#16938a');
    body.addColorStop(1, '#0b4f4a');
    ctx.fillStyle = body;
    ctx.beginPath();
    ctx.moveTo(-cw * 0.43, cw * 0.16);
    ctx.lineTo(-cw * 0.47, -cw * 0.24);
    ctx.lineTo(-cw * 0.32, -cw * 0.66);
    ctx.lineTo(cw * 0.32, -cw * 0.66);
    ctx.lineTo(cw * 0.47, -cw * 0.24);
    ctx.lineTo(cw * 0.43, cw * 0.16);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#45d6c4';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.fillStyle = '#ffbf69';
    ctx.fillRect(-cw * 0.06, -cw * 0.64, cw * 0.12, cw * 0.78);
    ctx.fillStyle = '#0a111c';
    ctx.beginPath();
    ctx.moveTo(-cw * 0.26, -cw * 0.32);
    ctx.lineTo(-cw * 0.2, -cw * 0.58);
    ctx.lineTo(cw * 0.2, -cw * 0.58);
    ctx.lineTo(cw * 0.26, -cw * 0.32);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#05080e';
    ctx.fillRect(-cw * 0.46, -cw * 0.06, cw * 0.92, cw * 0.1);
    ctx.fillRect(-cw * 0.3, 0, cw * 0.08, cw * 0.16);
    ctx.fillRect(cw * 0.22, 0, cw * 0.08, cw * 0.16);
    const braking = sim.brake > 0.1 || sim.handbrake;
    ctx.fillStyle = braking ? '#ff2f45' : '#7f1d24';
    ctx.shadowColor = braking ? 'rgba(255,47,69,0.85)' : 'transparent';
    ctx.shadowBlur = braking ? 18 : 0;
    ctx.fillRect(-cw * 0.42, -cw * 0.24, cw * 0.19, cw * 0.08);
    ctx.fillRect(cw * 0.23, -cw * 0.24, cw * 0.19, cw * 0.08);
    ctx.shadowBlur = 0;
    ctx.fillStyle = '#5b6779';
    ctx.fillRect(-cw * 0.22, cw * 0.14, cw * 0.08, cw * 0.08);
    ctx.fillRect(cw * 0.14, cw * 0.14, cw * 0.08, cw * 0.08);
    if (sim.backfireTimer > 0) {
      for (const side of [-1, 1]) {
        ctx.fillStyle = '#ff8a3d';
        ctx.beginPath();
        ctx.arc(side * cw * 0.18, cw * 0.25, cw * (0.08 + Math.random() * 0.05), 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#ffe29a';
        ctx.beginPath();
        ctx.arc(side * cw * 0.18, cw * 0.23, cw * 0.045, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  }

  private updateParticles(sim: ManualSim, dt: number) {
    if (!sim.paused && sim.camera === 'chase') {
      const w = this.width, h = this.height;
      const cx = w / 2 + sim.steer * 10, cy = h * 0.8;
      const cw = Math.min(w * 0.25, 155);
      if (sim.skidIntensity > 0.25 && Math.abs(sim.speed) > 8) {
        for (const side of [-1, 1]) {
          if (this.particles.length < 90 && Math.random() < 0.75) {
            this.particles.push({
              x: cx + side * cw * 0.4, y: cy + cw * 0.18,
              vx: (Math.random() - 0.5) * 30 - sim.steer * 20,
              vy: 20 + Math.random() * 35,
              life: 0.55, max: 0.55, size: 5 + Math.random() * 9, kind: 'smoke',
            });
          }
        }
      }
      if (sim.backfireTimer > 0.1 && this.particles.length < 90) {
        for (const side of [-1, 1]) {
          this.particles.push({
            x: cx + side * cw * 0.18, y: cy + cw * 0.25,
            vx: (Math.random() - 0.5) * 60, vy: 60 + Math.random() * 80,
            life: 0.22, max: 0.22, size: 2 + Math.random() * 2, kind: 'spark',
          });
        }
      }
    }
    for (const p of this.particles) {
      p.life -= dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.size += dt * (p.kind === 'smoke' ? 18 : 0);
    }
    this.particles = this.particles.filter(p => p.life > 0);
  }

  private drawParticles() {
    const ctx = this.ctx;
    for (const p of this.particles) {
      const a = clamp(p.life / p.max, 0, 1);
      ctx.fillStyle = p.kind === 'smoke' ? `rgba(190,198,210,${a * 0.28})` : `rgba(255,170,80,${a})`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private drawSpeedLines(sim: ManualSim) {
    const ctx = this.ctx, w = this.width, h = this.height;
    const strength = clamp((Math.abs(sim.speed) - 120) / 140, 0, 1);
    ctx.strokeStyle = `rgba(220,232,245,${0.14 * strength})`;
    ctx.lineWidth = 1.4;
    for (let i = 0; i < 14; i++) {
      const side = i % 2 ? -1 : 1;
      const t = ((performance.now() * 0.001 * (1.2 + i * 0.05)) + i * 0.13) % 1;
      const x = w / 2 + side * w * (0.28 + t * 0.42);
      const y = h * 0.45 + t * h * 0.55;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + side * 34 * t, y + 58 * t);
      ctx.stroke();
    }
  }
}
