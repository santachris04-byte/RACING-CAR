import { CarAudio } from './audio';

export type Gear = 'N' | 'R' | '1' | '2' | '3' | '4' | '5' | '6';
export type CameraMode = 'cockpit' | 'chase';
export type SteerMode = 'buttons' | 'slider' | 'tilt';
export type EventTone = 'info' | 'success' | 'warning' | 'error';
export interface SimEvent { type: string; tone: EventTone; message: string; shake?: number }
export interface TimingAttempt { time: number; date: number }
export interface TimingState {
  running: boolean;
  current: number;
  best: number | null;
  attempts: TimingAttempt[];
}

const STORAGE_KEY = 'pro-manual-sim-timing-v1';
const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export const GEAR_RATIOS: Record<Gear, number> = { R: -3.2, N: 0, '1': 3.6, '2': 2.2, '3': 1.52, '4': 1.15, '5': 0.92, '6': 0.74 };
const SPEED_CAPS: Record<Gear, number> = { R: -42, N: 280, '1': 58, '2': 98, '3': 145, '4': 188, '5': 228, '6': 268 };
export const GEAR_NAMES: Record<Gear, string> = { N: 'Neutral', R: 'Reverse', '1': '1st gear', '2': '2nd gear', '3': '3rd gear', '4': '4th gear', '5': '5th gear', '6': '6th gear' };

export class ManualSim {
  readonly audio = new CarAudio();
  engineRunning = false;
  cranking = false;
  starterTimer = 0;
  rpm = 0;
  idleRpm = 880;
  maxRpm = 7400;
  redlineRpm = 6600;
  gear: Gear = 'N';
  speed = 0;
  distance = 0;
  clutch = 1;
  clutchTarget = 1;
  gas = 0;
  gasTarget = 0;
  brake = 0;
  brakeTarget = 0;
  handbrake = true;
  steer = 0;
  steerTarget = 0;
  steerMode: SteerMode = 'buttons';
  carX = 0;
  trackPosition = 0;
  camera: CameraMode = 'cockpit';
  limiterActive = false;
  limiterCycle = 0;
  backfireTimer = 0;
  skidIntensity = 0;
  shake = 0;
  paused = false;
  timing: TimingState = { running: false, current: 0, best: null, attempts: [] };
  events: SimEvent[] = [];
  private prevSpeed = 0;
  private timerStart = 0;
  private offroadCooldown = 0;
  private stallCooldown = 0;

  constructor() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw) as Partial<TimingState>;
        if (typeof data.best === 'number' && Number.isFinite(data.best)) this.timing.best = data.best;
        if (Array.isArray(data.attempts)) {
          this.timing.attempts = data.attempts
            .filter((a): a is TimingAttempt => !!a && Number.isFinite(a.time) && Number.isFinite(a.date))
            .slice(0, 6);
        }
      }
    } catch { /* storage unavailable */ }
  }

  notify(message: string, tone: EventTone = 'info', type = 'status', shake = 0) {
    this.events.push({ type, tone, message, shake });
    if (shake > 0) this.shake = Math.max(this.shake, shake);
  }

  consumeEvents() {
    const out = this.events;
    this.events = [];
    return out;
  }

  setClutch(value: number) { this.clutchTarget = clamp(value, 0, 1); }
  setGas(value: number) { this.gasTarget = clamp(value, 0, 1); }
  setBrake(value: number) { this.brakeTarget = clamp(value, 0, 1); }
  setSteer(value: number) { this.steerTarget = clamp(value, -1, 1); }

  toggleHandbrake() {
    this.handbrake = !this.handbrake;
    this.notify(this.handbrake ? 'Handbrake applied.' : 'Handbrake released.', this.handbrake ? 'warning' : 'info');
  }

  togglePause() {
    this.paused = !this.paused;
    if (this.paused) {
      this.gasTarget = 0; this.brakeTarget = 0; this.steerTarget = 0;
      this.audio.updateEngine(0, 0, false, false);
      this.audio.updateTires(0);
    }
    this.notify(this.paused ? 'Simulation paused.' : 'Simulation resumed.', 'info');
  }

  toggleCamera() {
    this.camera = this.camera === 'cockpit' ? 'chase' : 'cockpit';
    this.notify(this.camera === 'cockpit' ? 'Camera: cockpit.' : 'Camera: chase.', 'info');
  }

  startEngine() {
    this.audio.init();
    this.audio.resume();
    if (this.cranking) return;
    if (this.engineRunning) {
      this.engineRunning = false;
      this.rpm = 0;
      this.notify('Engine switched off.', 'info');
      return;
    }
    if (this.gear !== 'N' && Math.max(this.clutch, this.clutchTarget) < 0.6) {
      this.audio.grind();
      this.notify('Cannot start in gear without the clutch. Select Neutral or hold Clutch.', 'error', 'deny', 5);
      return;
    }
    this.cranking = true;
    this.starterTimer = 0.55;
    this.audio.starter();
    this.notify('Starter cranking…', 'info');
  }

  selectGear(target: Gear) {
    if (target === this.gear) return;
    if (Math.max(this.clutch, this.clutchTarget) < 0.65) {
      this.audio.grind();
      this.notify('GEAR GRIND! Hold the clutch fully before selecting a gear.', 'error', 'grind', 9);
      return;
    }
    if (target === 'R' && Math.abs(this.speed) > 6) {
      this.audio.grind();
      this.notify('Reverse lockout: bring the car to a stop before selecting R.', 'warning', 'deny', 4);
      return;
    }
    if (target !== 'N' && target !== 'R' && this.speed < -2) {
      this.notify('Cannot select a forward gear while reversing.', 'warning', 'deny', 3);
      return;
    }
    this.gear = target;
    this.audio.shift();
    this.notify(`Selected ${GEAR_NAMES[target]}. Release the clutch gently with throttle.`, 'success', 'shift', 2.5);
  }

  resetCar() {
    this.speed = 0;
    this.steer = 0;
    this.steerTarget = 0;
    this.carX = 0;
    this.gear = 'N';
    this.clutch = 1;
    this.clutchTarget = 1;
    this.gas = 0; this.gasTarget = 0;
    this.brake = 0; this.brakeTarget = 0;
    this.handbrake = true;
    this.timing.running = false;
    this.timing.current = 0;
    this.notify('Car reset to the grid. Engine state preserved.', 'info');
  }

  clearTiming() {
    this.timing.best = null;
    this.timing.attempts = [];
    this.saveTiming();
    this.notify('Timing board cleared.', 'info');
  }

  private saveTiming() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ best: this.timing.best, attempts: this.timing.attempts }));
    } catch { /* ignore */ }
  }

  update(dt: number) {
    if (this.paused) return;
    dt = Math.min(dt, 0.034);
    this.audio.resume();

    // Pedal travel: clutch presses quickly, releases progressively for feathering.
    this.gas += (this.gasTarget - this.gas) * Math.min(1, dt * 11);
    this.brake += (this.brakeTarget - this.brake) * Math.min(1, dt * 12);
    const clutchRate = this.clutchTarget > this.clutch ? 22 : 3.4;
    this.clutch += (this.clutchTarget - this.clutch) * Math.min(1, dt * clutchRate);
    this.clutch = clamp(this.clutch, 0, 1);

    if (this.cranking) {
      this.starterTimer -= dt;
      this.rpm = 240 + Math.sin(this.starterTimer * 55) * 60;
      if (this.starterTimer <= 0) {
        this.cranking = false;
        if (this.gear !== 'N' && this.clutch < 0.6) {
          this.rpm = 0;
          this.notify('Start failed: clutch was released while in gear.', 'error', 'deny', 4);
        } else {
          this.engineRunning = true;
          this.rpm = this.idleRpm;
          this.notify('Engine running. Select 1st, release handbrake, feather clutch with throttle.', 'success', 'start', 2);
        }
      }
    }

    const engaged = 1 - this.clutch;
    const bite = clamp((engaged - 0.12) / 0.76, 0, 1);
    const ratio = GEAR_RATIOS[this.gear];
    const freeRev = this.gear === 'N' || engaged < 0.08;

    if (this.engineRunning) {
      const freeTarget = this.idleRpm + this.gas * (this.maxRpm - this.idleRpm);
      if (freeRev) {
        this.rpm += (freeTarget - this.rpm) * Math.min(1, dt * (this.gas > 0.1 ? 6.5 : 3.8));
      } else {
        const wheelRpm = (Math.abs(this.speed) / 3.6 / (0.32 * 2 * Math.PI)) * 60 * Math.abs(ratio) * 3.9;
        if (wheelRpm < 420 && engaged > 0.55 && this.gas < 0.12 && Math.abs(this.speed) < 3 && this.stallCooldown <= 0) {
          this.engineRunning = false;
          this.rpm = 0;
          this.stallCooldown = 1.2;
          this.audio.stall();
          this.timing.running = false;
          this.notify('ENGINE STALLED. You released the clutch without throttle. Press START to crank.', 'error', 'stall', 10);
          return;
        }
        const coupledTarget = Math.max(this.idleRpm * 0.65, wheelRpm);
        const targetRpm = lerp(freeTarget, coupledTarget, engaged);
        this.rpm += (targetRpm - this.rpm) * Math.min(1, dt * (6 + 10 * engaged));

        if (this.gas > 0.02 && !this.limiterActive) {
          const powerBand = Math.sin(clamp(this.rpm / this.maxRpm, 0, 1) * Math.PI);
          const idleAssist = this.rpm < 1650 ? 48 * (1 - this.rpm / 1650) : 0;
          const torque = this.gas * 300 * powerBand + idleAssist;
          const wheelForce = (torque * Math.abs(ratio) * 3.9) / 0.32;
          const acceleration = (wheelForce / 1280) * bite;
          this.speed += (this.gear === 'R' ? -1 : 1) * acceleration * dt * 3.6;
        }
      }

      if (this.rpm >= this.maxRpm - 90) {
        this.limiterActive = true;
        this.limiterCycle += dt * 48;
        this.rpm = this.maxRpm - (Math.sin(this.limiterCycle) > 0.1 ? 260 : 0);
        if (Math.random() < dt * 7) {
          this.backfireTimer = 0.13;
          this.audio.backfire();
          this.shake = Math.max(this.shake, 2.5);
        }
      } else {
        this.limiterActive = false;
      }
    } else if (!this.cranking) {
      this.rpm = Math.max(0, this.rpm - 1500 * dt);
      this.limiterActive = false;
    }

    // Engine braking, drag, brakes, rolling resistance.
    if (this.engineRunning && this.gas < 0.05 && engaged > 0.2 && this.gear !== 'N') {
      this.speed -= Math.sign(this.speed) * (1.1 + (this.rpm / this.maxRpm) * 2.4) * engaged * dt;
    }
    const drag = 0.00034 * this.speed * this.speed + 0.55;
    this.speed -= Math.sign(this.speed) * drag * dt;
    if (this.brake > 0.04) {
      this.speed -= Math.sign(this.speed) * Math.min(Math.abs(this.speed), this.brake * 40 * dt);
    }
    if (this.handbrake) {
      this.speed -= Math.sign(this.speed) * Math.min(Math.abs(this.speed), 52 * dt);
    }
    if (Math.abs(this.speed) > 0.1) {
      this.speed -= Math.sign(this.speed) * 1.5 * dt;
    } else if (this.gas === 0) {
      this.speed = 0;
    }

    const cap = SPEED_CAPS[this.gear];
    if (this.gear === 'R') {
      if (this.speed < cap) this.speed += (cap - this.speed) * Math.min(1, dt * 5);
      if (this.speed > 0) this.speed = Math.max(0, this.speed - 30 * dt);
    } else if (this.gear !== 'N' && this.speed > cap) {
      this.speed += (cap - this.speed) * Math.min(1, dt * 5);
    }
    this.speed = clamp(this.speed, -45, 285);

    // Steering and surface.
    this.steer += (this.steerTarget - this.steer) * Math.min(1, dt * 9);
    const sensitivity = Math.min(1, Math.max(0.18, 1 - Math.abs(this.speed) / 320));
    this.carX += this.steer * (this.speed / 70) * sensitivity * dt * 1.8;
    this.carX = clamp(this.carX, -1.8, 1.8);
    this.offroadCooldown = Math.max(0, this.offroadCooldown - dt);
    if (Math.abs(this.carX) > 1.04 && Math.abs(this.speed) > 4) {
      this.speed *= Math.max(0, 1 - dt * 0.95);
      this.shake = Math.max(this.shake, 1.6);
      if (this.offroadCooldown <= 0) {
        this.notify('Off line! Grass and gravel are slowing you down.', 'warning');
        this.offroadCooldown = 2.4;
      }
    }

    this.trackPosition += (this.speed / 3.6) * dt;
    this.distance += Math.abs(this.speed / 3.6) * dt;
    this.stallCooldown = Math.max(0, this.stallCooldown - dt);

    const hardBraking = this.brake > 0.7 && Math.abs(this.speed) > 25;
    const powerSlide = Math.abs(this.steer) > 0.6 && Math.abs(this.speed) > 60;
    const wheelspin = this.gas > 0.85 && bite > 0.6 && (this.gear === '1' || this.gear === '2') && Math.abs(this.speed) < 35 && this.rpm > 3000;
    const handbrakeSkid = this.handbrake && Math.abs(this.speed) > 10;
    const skidTarget = hardBraking || powerSlide || wheelspin || handbrakeSkid ? 1 : 0;
    this.skidIntensity += (skidTarget - this.skidIntensity) * Math.min(1, dt * 8);
    this.audio.updateTires(this.skidIntensity);
    this.audio.updateEngine(this.rpm, this.gas, this.engineRunning, this.limiterActive);

    // 0-100 km/h benchmark.
    const forward = this.gear !== 'N' && this.gear !== 'R';
    if (!this.timing.running && this.prevSpeed < 1 && this.speed >= 1 && this.speed < 12 && forward && !this.handbrake) {
      this.timing.running = true;
      this.timerStart = performance.now();
      this.timing.current = 0;
      this.notify('0–100 km/h timer live. Keep it clean.', 'info');
    }
    if (this.timing.running) {
      this.timing.current = (performance.now() - this.timerStart) / 1000;
      if (this.speed >= 100) {
        const time = this.timing.current;
        this.timing.running = false;
        this.timing.attempts = [{ time, date: Date.now() }, ...this.timing.attempts].slice(0, 6);
        const isBest = this.timing.best === null || time < this.timing.best;
        if (isBest) this.timing.best = time;
        this.saveTiming();
        this.audio.success();
        this.notify(isBest ? `NEW BEST 0–100: ${time.toFixed(2)} s!` : `0–100 complete: ${time.toFixed(2)} s.`, 'success', 'finish', 3);
      } else if (this.speed < 0.5 || this.gear === 'R') {
        this.timing.running = false;
        this.notify('Timing run aborted.', 'warning');
      }
    }
    this.prevSpeed = this.speed;
    this.backfireTimer = Math.max(0, this.backfireTimer - dt);
    this.shake *= Math.exp(-6 * dt);
  }
}
