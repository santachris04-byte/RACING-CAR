export class CarAudio {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private engineGain: GainNode | null = null;
  private tireGain: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private osc1: OscillatorNode | null = null;
  private osc2: OscillatorNode | null = null;
  private subOsc: OscillatorNode | null = null;
  private noise: AudioBufferSourceNode | null = null;
  muted = true;

  init() {
    if (this.ctx) return;
    try {
      const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!Ctor) return;
      const ctx = new Ctor();
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.34;
      const compressor = ctx.createDynamicsCompressor();
      compressor.threshold.value = -18;
      compressor.ratio.value = 6;
      this.master.connect(compressor);
      compressor.connect(ctx.destination);

      this.filter = ctx.createBiquadFilter();
      this.filter.type = 'lowpass';
      this.filter.frequency.value = 360;
      this.engineGain = ctx.createGain();
      this.engineGain.gain.value = 0;
      this.filter.connect(this.engineGain);
      this.engineGain.connect(this.master);

      this.osc1 = ctx.createOscillator();
      this.osc1.type = 'sawtooth';
      this.osc2 = ctx.createOscillator();
      this.osc2.type = 'triangle';
      this.subOsc = ctx.createOscillator();
      this.subOsc.type = 'sine';
      this.osc1.connect(this.filter);
      this.osc2.connect(this.filter);
      this.subOsc.connect(this.filter);
      this.osc1.start();
      this.osc2.start();
      this.subOsc.start();

      const length = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
      this.noise = ctx.createBufferSource();
      this.noise.buffer = buffer;
      this.noise.loop = true;
      const tireFilter = ctx.createBiquadFilter();
      tireFilter.type = 'bandpass';
      tireFilter.frequency.value = 950;
      tireFilter.Q.value = 2.6;
      this.tireGain = ctx.createGain();
      this.tireGain.gain.value = 0;
      this.noise.connect(tireFilter);
      tireFilter.connect(this.tireGain);
      this.tireGain.connect(this.master);
      this.noise.start();
    } catch {
      this.ctx = null;
    }
  }

  resume() {
    if (this.ctx?.state === 'suspended') void this.ctx.resume().catch(() => {});
  }

  setMuted(muted: boolean) {
    this.muted = muted;
    if (this.ctx && this.master) {
      this.master.gain.setTargetAtTime(muted ? 0 : 0.34, this.ctx.currentTime, 0.05);
    }
  }

  updateEngine(rpm: number, throttle: number, running: boolean, limiterCut: boolean) {
    if (!this.ctx || !this.engineGain || !this.osc1 || !this.osc2 || !this.subOsc || !this.filter) return;
    const now = this.ctx.currentTime;
    if (!running || this.muted) {
      this.engineGain.gain.setTargetAtTime(0, now, 0.08);
      return;
    }
    const freq = Math.max(22, (rpm / 60) * 2);
    this.osc1.frequency.setTargetAtTime(freq, now, 0.03);
    this.osc2.frequency.setTargetAtTime(freq * 1.5, now, 0.03);
    this.subOsc.frequency.setTargetAtTime(freq * 0.5, now, 0.03);
    this.filter.frequency.setTargetAtTime(220 + (rpm / 7500) * 2200 + throttle * 900, now, 0.04);
    let gain = 0.2 + throttle * 0.32 + (rpm / 7500) * 0.26;
    if (limiterCut) gain *= 0.06;
    this.engineGain.gain.setTargetAtTime(gain, now, 0.02);
  }

  updateTires(slip: number) {
    if (!this.ctx || !this.tireGain) return;
    this.tireGain.gain.setTargetAtTime(this.muted ? 0 : Math.min(0.38, slip * 0.42), this.ctx.currentTime, 0.05);
  }

  private blip(freq: number, end: number, duration: number, gain: number, type: OscillatorType = 'sine') {
    if (!this.ctx || !this.master || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(Math.max(1, end), now + duration);
    g.gain.setValueAtTime(gain, now);
    g.gain.linearRampToValueAtTime(0.001, now + duration);
    osc.connect(g);
    g.connect(this.master);
    osc.start(now);
    osc.stop(now + duration + 0.02);
    osc.onended = () => { osc.disconnect(); g.disconnect(); };
  }

  shift() { this.blip(150, 42, 0.08, 0.5, 'triangle'); }
  grind() {
    this.blip(90, 160, 0.09, 0.55, 'sawtooth');
    this.blip(160, 70, 0.2, 0.4, 'sawtooth');
  }
  starter() { this.blip(24, 34, 0.55, 0.32, 'square'); }
  stall() { this.blip(72, 14, 0.4, 0.55, 'sawtooth'); }
  success() {
    this.blip(660, 880, 0.12, 0.25, 'triangle');
    this.blip(880, 1320, 0.24, 0.2, 'triangle');
  }
  backfire() {
    if (!this.ctx || !this.master || this.muted) return;
    const ctx = this.ctx;
    const buffer = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.1), ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.02));
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const g = ctx.createGain();
    g.gain.value = 0.7;
    src.connect(g);
    g.connect(this.master);
    src.start();
    src.onended = () => { src.disconnect(); g.disconnect(); };
  }

  destroy() {
    try {
      this.osc1?.stop(); this.osc2?.stop(); this.subOsc?.stop(); this.noise?.stop();
      if (this.ctx && this.ctx.state !== 'closed') void this.ctx.close().catch(() => {});
    } catch { /* already closed */ }
    this.ctx = null;
  }
}
